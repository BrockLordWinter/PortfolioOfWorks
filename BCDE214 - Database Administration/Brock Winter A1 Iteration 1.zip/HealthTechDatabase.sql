CREATE DATABASE HealthTech;
USE HealthTech;

CREATE TABLE IF NOT EXISTS Worker(
workerID int primary key,
workerName varchar(20)
) engine = InnoDB;

CREATE TABLE IF NOT EXISTS Contactor(
contactorID int primary key,
contactorName varchar(20)
) engine = InnoDB;

CREATE TABLE IF NOT EXISTS Carer(
carerID int primary key,
carerName varchar(20)
) engine = InnoDB;

CREATE TABLE IF NOT EXISTS Patient(
patientID int primary key,
patientName varchar(20),
contactorID int,
contactorName varchar(20),
carerID int primary key,
carerName varchar(20),
foreign key (carerID) references Carer (carerID),
foreign key (contactorID) references Contactor (contactorID)
) engine = InnoDB;

CREATE TABLE IF NOT EXISTS Contact(
contactID int primary key,
contactName varchar(20),
patientID int,
patientName varchar(20),
contactDate date,
contactorID int,
contactorName varchar(20),
workerID int,
workerName varchar(20),
actionsTaken varchar(200),
foreign key (workerID) references Worker (workerID),
foreign key (contactorID) references Contactor (contactorID),
foreign key (patientID) references Patient (patientID)
) engine = InnoDB;





