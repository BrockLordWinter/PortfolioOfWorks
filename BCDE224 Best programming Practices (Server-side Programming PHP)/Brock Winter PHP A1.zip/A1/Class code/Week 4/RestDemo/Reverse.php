<?php 

class Reversed 
{
	public $letters;
	protected $reverseStr;
	public function __construct($newLetter) 
	{
		$this->letters = $newLetter;
	}	
	public function convert()
	{

		$size = strlen($this->letters);         
		for ($i = ($size - 1); $i >= 0; $i --)
		{
			$this->reverseStr .= $this->letters[$i];
		}

	}

	public function getRevStr() 
	{
		if ( isset( $this->reverseStr ) ) 
		{
			return $this->reverseStr;
		}
	}
}
?>