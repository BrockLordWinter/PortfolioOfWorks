<?php namespace bar;
  class Dog {
    static function says() {echo 'ruff';}  } ?>