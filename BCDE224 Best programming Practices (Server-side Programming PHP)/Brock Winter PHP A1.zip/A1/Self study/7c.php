<?php
$firstNum;
$secondNum = 5;
for ( $firstNum = 0; ;$firstNum++) {
    if ($firstNum > $secondNum) {
        break;
    }
    echo $firstNum;
}
?>