BACKUP LOG [Vaccinations] TO  DISK = N'G:\2021 sem 2\BCDE214 Database Administration\A2\pA\Portfolio\VaccinesStudent.bak' WITH  RETAINDAYS = 1, NOFORMAT, NOINIT,  NAME = N'Vaccinations-Full Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10, CHECKSUM
GO
declare @backupSetId as int
select @backupSetId = position from msdb..backupset where database_name=N'Vaccinations' and backup_set_id=(select max(backup_set_id) from msdb..backupset where database_name=N'Vaccinations' )
if @backupSetId is null begin raiserror(N'Verify failed. Backup information for database ''Vaccinations'' not found.', 16, 1) end
RESTORE VERIFYONLY FROM  DISK = N'G:\2021 sem 2\BCDE214 Database Administration\A2\pA\Portfolio\VaccinesStudent.bak' WITH  FILE = @backupSetId,  NOUNLOAD,  NOREWIND
GO

BACKUP DATABASE [Vaccinations] TO  DISK = N'G:\2021 sem 2\BCDE214 Database Administration\A2\pA\Portfolio\VaccinesStudent.bak' WITH  RETAINDAYS = 14, NOFORMAT, NOINIT,  NAME = N'Vaccinations-Full Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10, CHECKSUM
GO
declare @backupSetId as int
select @backupSetId = position from msdb..backupset where database_name=N'Vaccinations' and backup_set_id=(select max(backup_set_id) from msdb..backupset where database_name=N'Vaccinations' )
if @backupSetId is null begin raiserror(N'Verify failed. Backup information for database ''Vaccinations'' not found.', 16, 1) end
RESTORE VERIFYONLY FROM  DISK = N'G:\2021 sem 2\BCDE214 Database Administration\A2\pA\Portfolio\VaccinesStudent.bak' WITH  FILE = @backupSetId,  NOUNLOAD,  NOREWIND
GO

BACKUP DATABASE [Vaccinations] TO  DISK = N'G:\2021 sem 2\BCDE214 Database Administration\A2\pA\Portfolio\VaccinesStudent.bak' WITH  DIFFERENTIAL , NOFORMAT, NOINIT,  NAME = N'Vaccinations-Full Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10, CHECKSUM
GO
declare @backupSetId as int
select @backupSetId = position from msdb..backupset where database_name=N'Vaccinations' and backup_set_id=(select max(backup_set_id) from msdb..backupset where database_name=N'Vaccinations' )
if @backupSetId is null begin raiserror(N'Verify failed. Backup information for database ''Vaccinations'' not found.', 16, 1) end
RESTORE VERIFYONLY FROM  DISK = N'G:\2021 sem 2\BCDE214 Database Administration\A2\pA\Portfolio\VaccinesStudent.bak' WITH  FILE = @backupSetId,  NOUNLOAD,  NOREWIND
GO
