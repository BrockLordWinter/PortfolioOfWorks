<?php 
$title = '';
switch ($title){
	case 'Harry Potter':
	echo "Nice story, a bit too long.";
	break;
	case 'Lord of the Rings':
	echo "A Classic.";
	break;
	default:
	echo "Dunno that one.";
	break;
}