select carerID, carerFirstName
from carer
where carerFirstName LIKE 's%';

select contactorID, contactorFirstName, contactDate, contactDescription
from contact
where carerFirstName LIKE 's%';