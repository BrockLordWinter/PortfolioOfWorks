CREATE DATABASE IF NOT EXISTS AgoraDB DEFAULT CHARSET = utf8;
USE AgoraDB;

DROP TABLE IF EXISTS buyer;
CREATE TABLE buyer (
    buyerId               INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY, 
    fName                 VARCHAR(30),
    lName                 VARCHAR(30),
    address               VARCHAR(100),
    city                  VARCHAR(30),
    email			      VARCHAR(150)
) ENGINE=InnoDB;

INSERT INTO buyer ( fName, lName, address, city, email ) VALUES ( 'Bill', 'Smith', 'address 1', 'city 1', 'email 1' );
INSERT INTO buyer ( fName, lName, address, city, email ) VALUES ( 'Billy', 'Smell', 'address 2', 'city 2', 'email 2' );
INSERT INTO buyer ( fName, lName, address, city, email ) VALUES ( 'Bob', 'Small', 'address 3', 'city 3', 'email 3' );

DROP TABLE IF EXISTS supplier;
CREATE TABLE supplier (
    supplierId            INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY, 
    fName                 VARCHAR(30),
    lName                 VARCHAR(30),
    companyName			  VARCHAR(50),
    address               VARCHAR(100),
    city                  VARCHAR(30),
    email			      VARCHAR(150)    
) ENGINE=InnoDB;

INSERT INTO supplier ( fName, lName, address, companyName, city, email ) VALUES ( 'Amber', 'White', 'company1', 'address 4', 'city 4', 'email 4' );
INSERT INTO supplier ( fName, lName, address, companyName, city, email ) VALUES ( 'Abby', 'White', 'company1', 'address 4', 'city 4', 'email 5' );
INSERT INTO supplier ( fName, lName, address, companyName, city, email ) VALUES ( 'Angus', 'Red', 'company2', 'address 5', 'city 5', 'email 6' );

DROP TABLE IF EXISTS product;
CREATE TABLE product (
    productId              INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
    supplierId            INTEGER,
    productName            VARCHAR(50),
    productDescription     TEXT,
    price				   INTEGER,
	INDEX suppID (supplierId),
    CONSTRAINT suppID FOREIGN KEY suppID(supplierId) REFERENCES supplier(supplierId)
        ON UPDATE RESTRICT
        ON DELETE SET NULL
) ENGINE=InnoDB;

INSERT INTO product ( supplierId, productName, productDescription, price ) VALUES ( '1', 'Chocolate', 'Cadbary Chocolate', 3);
INSERT INTO product ( supplierId, productName, productDescription, price ) VALUES ( '1', 'Snakes', 'candy', 2);
INSERT INTO product ( supplierId, productName, productDescription, price ) VALUES ( '3', 'Table', 'Furniture', 250);

DROP TABLE IF EXISTS stock;
CREATE TABLE stock (
	stockID 			   INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
    productId              INTEGER,
    quantity 		       INTEGER, 
    INDEX producID (productId),
    CONSTRAINT producID FOREIGN KEY producID(productId) REFERENCES product(productId)
        ON UPDATE RESTRICT
        ON DELETE SET NULL
) ENGINE=InnoDB;

INSERT INTO stock ( productId, quantity) VALUES ( 1, 3);
INSERT INTO stock ( productId, quantity) VALUES ( 1, 3);
INSERT INTO stock ( productId, quantity) VALUES ( 3, 2);


DROP TABLE IF EXISTS myFavourites;
CREATE TABLE myFavourites (
    myFavouritesId         INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
    buyerId				   INTEGER,
    INDEX buyerId (buyerId),
    CONSTRAINT buyerId FOREIGN KEY buyerId(buyerId) REFERENCES buyer(buyerId)
        ON UPDATE RESTRICT
        ON DELETE SET NULL
) ENGINE=InnoDB;

INSERT INTO myFavourites ( buyerId) VALUES (1);
INSERT INTO myFavourites ( buyerId) VALUES (2);
INSERT INTO myFavourites ( buyerId) VALUES (3);

DROP TABLE IF EXISTS favourite;
CREATE TABLE favourite (
    favouriteId            INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
    productId              INTEGER,
    productName            VARCHAR(50),
    productDescription     TEXT,
    myFavouritesId         INTEGER,
    INDEX prodID (productId),
    CONSTRAINT prodID FOREIGN KEY prodID(productId) REFERENCES product(productId)
        ON UPDATE RESTRICT
        ON DELETE SET NULL,
	INDEX favID (myFavouritesId),
    CONSTRAINT favID FOREIGN KEY favID(myFavouritesId) REFERENCES myFavourites(myFavouritesId)
        ON UPDATE RESTRICT
        ON DELETE SET NULL
) ENGINE=InnoDB;

INSERT INTO favourite ( productId, productName, productDescription, myFavouritesId) VALUES ( 3, 'Table', 'Furniture', 1);
INSERT INTO favourite ( productId, productName, productDescription, myFavouritesId) VALUES ( 2, 'Snakes', 'candy', 1);
INSERT INTO favourite ( productId, productName, productDescription, myFavouritesId) VALUES ( 3, 'Table', 'Furniture', 2);

DROP TABLE IF EXISTS cart;
CREATE TABLE cart (
    cartId                 INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
    totalCost 		       INTEGER,
	buyerId				   INTEGER,
    INDEX buyerId1 (buyerId),
    CONSTRAINT buyerId1 FOREIGN KEY buyerId1(buyerId) REFERENCES buyer(buyerId)
        ON UPDATE RESTRICT
        ON DELETE SET NULL
) ENGINE=InnoDB;

INSERT INTO cart ( totalCost, buyerId) VALUES (0, 1);
INSERT INTO cart ( totalCost, buyerId) VALUES (0, 2);
INSERT INTO cart ( totalCost, buyerId) VALUES (0, 3);

DROP TABLE IF EXISTS addToCart;
CREATE TABLE addToCart (
    addToCartId            INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
    cartId				   INTEGER,
    productId              INTEGER,
    productName            VARCHAR(50),
    discountAmount         INTEGER,
    quantity 		       INTEGER,
    price				   INTEGER,
    totalPrice		       INTEGER AS ((price - discountAmount) * quantity),
    INDEX cartId (cartId),
    CONSTRAINT cartId FOREIGN KEY cartId(cartId) REFERENCES cart(cartId)
        ON UPDATE RESTRICT
        ON DELETE SET NULL,
    INDEX produID (productId),
    CONSTRAINT produID FOREIGN KEY produID(productId) REFERENCES stock(productId)
        ON UPDATE RESTRICT
        ON DELETE SET NULL
) ENGINE=InnoDB;

INSERT INTO addToCart ( cartId, productId, productName, discountAmount, quantity, price ) VALUES ( 1, 3, 'Table', 0, 1, 250);
INSERT INTO addToCart ( cartId, productId, productName, discountAmount, quantity, price ) VALUES ( 2, 1, 'Chocolate', 0, 1, 3);
INSERT INTO addToCart ( cartId, productId, productName, discountAmount, quantity, price ) VALUES ( 3, 3, 'Table', 20, 2, 250);

