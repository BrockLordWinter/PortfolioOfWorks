-- =============================================

-- Description:	Create Procedure to Bulk Load Appointments

-- =============================================



-- Choose teh data base, delete teh previous procedure if it is there

USE Vaccinations

GO

DROP PROCEDURE IF EXISTS bulkLoadAppointments

GO



-- Create the procedure

CREATE PROCEDURE bulkLoadAppointments 

	-- Loads a file of appointments into the Appointment table.  No error checking.

	@fileName varchar(100) = '',	-- The file naem where the data is being loaded from
	@startApptNumber int,			-- Start and end slot to load the data
	@endApptNumber int
AS
BEGIN
	DECLARE @sqlString varchar(512) = '' -- The string that is being executed to bulk load the data

	--  Create the temporary table to load the data into to loop through

	DROP TABLE IF EXISTS #newAppointments
	SELECT TOP 0 * INTO #newAppointments FROM Appointment
	CREATE TABLE #newAppointments (
		id int,
		placeId char(10),
		slot tinyint,
		apptTime datetime,
		vaccineNumber tinyint,
		personId char(12),
		vialNumber char(15),
		vaccinator char(10)
	)



	-- Create and execute the sql string.  The quotes are important
	SET @sqlString = '
	BULK INSERT #vaccinatorPreferred
	FROM '''  + @fileName + '''
	WITH (
		FIRSTROW = 2,
		FIELDTERMINATOR = '','',
		ROWTERMINATOR=''\n''
	)'
	EXECUTE (@sqlString)
	

	-- Use a cursor to loop through the temporary table, and load the data into the permanent table

	-- Variables data read from
	DECLARE @id int
	DECLARE @placeId char(10)
	DECLARE @slot tinyint
	DECLARE @apptTime datetime
	DECLARE @vaccineNumber tinyint
	DECLARE @personId char(12)
	DECLARE @vialNumber char(15)
	DECLARE @vaccinator char(10)

	DECLARE newAppointmentsCursor CURSOR FOR
			SELECT id FROM #newAppointments

	OPEN newAppointmentsCursor
	

	-- Loop through the cursor until there is no more data

	FETCH NEXT FROM newAppointmentsCursor INTO @id

	WHILE @startApptNumber <= @endApptNumber

		BEGIN
			SELECT @id = id, @placeId = placeId, @slot = slot, @apptTime = apptTime, @vaccineNumber = vaccineNumber, @personId = personId, @vialNumber = vialNumber, @vaccinator = vaccinator
			FROM #newAppointments			-- Get the data from teh temporary table

			-- Run the procedure that enters the data

			EXEC CreateWholeDayAppointments @placeId=@placeId,@day=@apptTime,@startTime=startTime,@endTime=endTime,@timeBetweenAppointments=timeBetweenAppointments,@slots=slots

			-- Get the next lot of data
			FETCH NEXT FROM newAppointmentsCursor INTO @id
			

		END



	-- Tidy up

	CLOSE newAppointmentsCursor
	DEALLOCATE newAppointmentsCursor
	DROP TABLE #newAppointments
END 
GO





-- Testing data

--DELETE FROM Appointment
GO

--SELECT * FROM Appointment
GO

--EXEC bulkLoadAppointments @fileName = 'C:\Temp\Vaccine2021\SiteSessionsAugust.csv'
GO

--SELECT count(*) AS AppointmentCount FROM Appointment