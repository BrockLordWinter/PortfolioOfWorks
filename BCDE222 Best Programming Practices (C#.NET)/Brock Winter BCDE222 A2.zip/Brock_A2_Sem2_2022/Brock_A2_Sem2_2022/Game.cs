﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Brock_A2_Sem2_2022
{
    class Game : IGame
    {
        public int GetMoveCount()
        {
            throw new NotImplementedException();
        }

        public bool IsFinished()
        {
            throw new NotImplementedException();
        }

        public void Load(string newLevel)
        {
            throw new NotImplementedException();
        }

        public void Move(Direction moveDirection)
        {
            throw new NotImplementedException();
        }

        public void Restart()
        {
            throw new NotImplementedException();
        }

        public void Undo()
        {
            throw new NotImplementedException();
        }
    }
}
