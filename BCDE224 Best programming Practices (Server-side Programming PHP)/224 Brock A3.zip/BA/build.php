<?php
require_once 'siteFunctions/commonFunctions.php';
require_once 'siteFunctions/masterPage.php';
require_once 'framework/MySQLDB.php';

	try {
		$db=getNewDatabase();
		$db->execute( "drop table if exists buyers");
		$db->execute( "create table buyers
						(buyerID  		integer not null AUTO_INCREMENT,
						 fName 			char(30),
						 lName 			char(30),
						 address		char(100),
						 city			char(30),
						 email			char(150),
						 primary key	(buyerID), 
						 unique key 	(fName)
						)");
	   
		$db->execute( "insert into buyers values ( 1, 'Bill', 'Smith', 'address 1', 'city 1', 'email 1')") ;
		$db->execute( "insert into buyers values ( 2, 'Billy', 'Smell', 'address 2', 'city 2', 'email 2')" )  ;
		$db->execute( "insert into buyers values ( 3, 'Bob', 'Small', 'address 3', 'city 3', 'email 3' )" ) ;
		
		
		$db->execute( "drop table if exists supplier");
		$db->execute( "create table supplier
						(supplierId  	integer not null AUTO_INCREMENT,
						 fName 			char(30),
						 lName 			char(30),
						 companyName	VARCHAR(50),
						 address		char(100),
						 city			char(30),
						 email			char(150),
						 primary key	(supplierId)
						)");
	   
		$db->execute( "insert into supplier values ( 1, 'Amber', 'White', 'company1', 'address 4', 'city 4', 'email 4')") ;
		$db->execute( "insert into supplier values ( 2, 'Abby', 'White', 'company1', 'address 4', 'city 4', 'email 5')" )  ;
		$db->execute( "insert into supplier values ( 3, 'Angus', 'Red', 'company2', 'address 5', 'city 5', 'email 6' )" ) ;
		
		
		$db->execute( "drop table if exists product");
		$db->execute( "create table product
						(productId  			integer not null AUTO_INCREMENT,
						 supplierId     		INTEGER,
						 productName            VARCHAR(50),
						 productDescription     TEXT,
						 price				    INTEGER,
						 primary key			(productId),
						 INDEX suppID (supplierId),
						 CONSTRAINT suppID FOREIGN KEY suppID(supplierId) REFERENCES supplier(supplierId)
							ON UPDATE RESTRICT
							ON DELETE SET NULL
						)");
						 
		$db->execute( "insert into product values (  '1', 'Chocolate', 'Cadbary Chocolate', 3 )" );
		$db->execute( "insert into product values ( '1', 'Snakes', 'candy', 2 )" );
		$db->execute( "insert into product values ( '3', 'Table', 'Furniture', 250 )" );
		
		$db->execute( "drop table if exists stock");
		$db->execute( "create table stock
						(stockID 			   	INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
						 productId              INTEGER,
						 quantity 		       	INTEGER, 
						 INDEX producID (productId),
						 CONSTRAINT producID FOREIGN KEY producID(productId) REFERENCES product(productId)
							ON UPDATE RESTRICT
							ON DELETE SET NULL
						)");
							 
		$db->execute( "insert into stock values (  1, 3 )" );
		$db->execute( "insert into stock values ( 1, 3 )" );
		$db->execute( "insert into stock values ( 3, 2 )" );
		
		$db->execute( "drop table if exists myFavourites");
		$db->execute( "create table myFavourites
						(myFavouritesId 		INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
						 productId              INTEGER,
						 buyerId 		       	INTEGER, 
						 INDEX buyerId (buyerId),
						 CONSTRAINT buyerId FOREIGN KEY buyerId(buyerId) REFERENCES buyer(buyerId)
							ON UPDATE RESTRICT
							ON DELETE SET NULL
						)");
							 
		$db->execute( "insert into myFavourites values ( 1 )" );
		$db->execute( "insert into myFavourites values ( 2 )" );
		$db->execute( "insert into myFavourites values ( 3 )" );
		
		$db->execute( "drop table if exists favourite");
		$db->execute( "create table favourite
						(favouriteId 			INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
						 productId              INTEGER,
						 productName            VARCHAR(50),
						 productDescription     TEXT,
						 myFavouritesId         INTEGER,
						 INDEX prodID (productId),
						 CONSTRAINT prodID FOREIGN KEY prodID(productId) REFERENCES product(productId)
							ON UPDATE RESTRICT
							ON DELETE SET NULL,
						 INDEX favID (myFavouritesId),
						 CONSTRAINT favID FOREIGN KEY favID(myFavouritesId) REFERENCES myFavourites(myFavouritesId)
							ON UPDATE RESTRICT
							ON DELETE SET NULL
						)");
							 
		$db->execute( "insert into favourite values ( 3, 'Table', 'Furniture', 1 )" );
		$db->execute( "insert into favourite values ( 2, 'Snakes', 'candy', 1 )" );
		$db->execute( "insert into favourite values ( 3, 'Table', 'Furniture', 2 )" );
		
		$db->execute( "drop table if exists cart");
		$db->execute( "create table cart
						(cartId 				INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
						 totalCost              INTEGER,
						 buyerId         		INTEGER,
						 INDEX buyerId1 (buyerId),
						 CONSTRAINT buyerId1 FOREIGN KEY buyerId1(buyerId) REFERENCES buyer(buyerId)
							ON UPDATE RESTRICT
							ON DELETE SET NULL
						)");
							 
		$db->execute( "insert into cart values ( 0, 1 )" );
		$db->execute( "insert into cart values ( 0, 2 )" );
		$db->execute( "insert into cart values ( 0, 3 )" );
		
		$db->execute( "drop table if exists addToCart");
		$db->execute( "create table addToCart
						(addToCartId            INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
						 cartId				   INTEGER,
						 productId              INTEGER,
						 productName            VARCHAR(50),
						 discountAmount         INTEGER,
						 quantity 		       INTEGER,
						 price				   INTEGER,
						 totalPrice		       INTEGER AS ((price - discountAmount) * quantity),
						 INDEX cartId (cartId),
						 CONSTRAINT cartId FOREIGN KEY cartId(cartId) REFERENCES cart(cartId)
							ON UPDATE RESTRICT
							ON DELETE SET NULL,
						 INDEX produID (productId),
						 CONSTRAINT produID FOREIGN KEY produID(productId) REFERENCES stock(productId)
							ON UPDATE RESTRICT
							ON DELETE SET NULL
						)");
							 
		$db->execute( "insert into addToCart values ( 1, 3, 'Table', 0, 1, 250 )" );
		$db->execute( "insert into addToCart values ( 2, 1, 'Chocolate', 0, 1, 3 )" );
		$db->execute( "insert into addToCart values ( 3, 3, 'Table', 20, 2, 250 )" );
		
		
		
		
			
		$content='<p>The database has been built.</p>';
		
		$pg=new MasterPage();
		$pg->setTitle('Database build/rebuild');
		$pg->setContent($content);
		print $pg->getHtml();
		
	} catch (exception $ex) {
		print $ex;
	}

