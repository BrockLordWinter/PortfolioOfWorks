<?php
    preg_match_all ('/(\S[^:]+): (\d+)/', $mysqli->info, $matches);
    $info = array_combine ($matches[1], $matches[2]);
?>

Procedural style:

<?php
    preg_match_all ('/(\S[^:]+): (\d+)/', mysqli_info ($link), $matches);
    $info = array_combine ($matches[1], $matches[2]);
?>

You can then use the array to test for the different conditions

<?php
    if ($info ['Rows matched'] == 0) {
        echo "This operation did not match any rows.\n";
    } elseif ($info ['Changed'] == 0) {
        echo "This operation matched rows, but none required updating.\n";
    }

    if ($info ['Changed'] < $info ['Rows matched']) {
        echo ($info ['Rows matched'] - $info ['Changed'])." rows matched but were not changed.\n";
    }
?>