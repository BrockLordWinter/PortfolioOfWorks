<?php echo 'if you want to serve PHP code in XHTML or XML documents,
                use these tags'; ?>