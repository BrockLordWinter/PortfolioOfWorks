<?php
$favFood = array("Chicken", "Chocolate", "Ice Cream");
echo "My favourite foods are " . $favFood[0] . ", " . $favFood[1] . " and " . $favFood[2] . ".";
?>