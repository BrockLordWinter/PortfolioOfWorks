<?php namespace foo;
  class Cat {
    static function says() {echo 'meoow';}  } ?>
