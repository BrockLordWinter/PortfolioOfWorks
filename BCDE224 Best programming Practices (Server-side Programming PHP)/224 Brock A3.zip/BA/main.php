<?php
require_once 'siteFunctions/masterPage.php';

	$pg=new MasterPage();
	if ($pg->getMember()!=null) {
		header("location: memberPage.php");
	} else {
			
		#$content='<p></p>';
		$content='<p></p>';
		$content.='<p>Login using <strong>guest</strong> and password <strong> pa$$word </strong>:';
		#$content.='<p><strong>search.php</strong></p>';
		#$content.='<p><strong>memberPage.php</strong></p>';
		#$content.='<p><strong>book.php</strong></p>';
		
		$content.='<p>The search script should ask the user to enter a search term. '.
				  'It should then display an HTML table showing the Booking ID,'.
				  ' MemberID, and room number which match the term '.
				  'on Booking ID, MemberID, or room number.</p>';

		$content.='<p>The user does not need to login to carry out a search. However, '.
		          'the member and booking scripts are only available to logged in users.</p>';

				   
		$pg->setTitle('Welcome and Instructions');
		$pg->setContent($content);
		print $pg->getHtml();
	}


