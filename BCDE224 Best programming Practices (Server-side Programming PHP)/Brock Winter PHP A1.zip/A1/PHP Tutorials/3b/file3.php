<?php namespace animate;
  class Animal {
    static function breathes() {echo 'air';}  } ?>