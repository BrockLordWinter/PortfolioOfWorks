﻿namespace Brock_A2_Sem2_2022
{
    public enum Direction { Up, UpRight, Right, DownRight, Down, DownLeft, Left, UpLeft }
}
