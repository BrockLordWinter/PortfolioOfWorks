<?php
function sayHello() 
{
	echo "hello 224";
}
sayHello();
?>