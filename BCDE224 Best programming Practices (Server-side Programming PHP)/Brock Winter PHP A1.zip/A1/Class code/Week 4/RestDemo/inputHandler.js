
const fetchReverseString = async (input, targetElement) => {
    const res = await fetch(`http://localhost/Week4/RestDemo/reverseHandler.php?${input}`)
	.catch(error => (handleError(error, targetElement)))
    const data = await res.json();
    return data;
}

const displayReverse = async (input, targetElement) => {
    const data = await fetchReverseString(input, targetElement);
    targetElement.innerText = JSON.stringify(data)
}

const handleError = (err, targetElement) => {
    targetElement.innerText = err
}