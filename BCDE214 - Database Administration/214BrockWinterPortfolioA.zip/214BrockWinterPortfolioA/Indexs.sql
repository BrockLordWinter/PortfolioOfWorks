use [Vaccinations]
GO
CREATE NONCLUSTERED INDEX [WhoIsBeingVacinated] ON Appointment([personId])
select [preferredName] from [dbo].[Appointment]
inner join [dbo].[AllPeople] on [NHI]=[personId]
where [NHI]=[personId];


CREATE NONCLUSTERED INDEX [WhoIsVaccinating] ON Appointment([vaccinator])
select [preferredName] from [dbo].[Appointment]
inner join [dbo].[Vaccinator] on [iRDNumber]=[vaccinator]
where [vaccinator] = [iRDNumber];

CREATE NONCLUSTERED INDEX [WhereArePeopleVaccinating] ON Appointment([placeId])
select [longName] from [dbo].[Appointment]
inner join [dbo].[Place] p on p.[id]=[placeId]
where [placeId] = p.[id];