package com.example.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private Button button;
    TextView message00;
    TextView message01;
    TextView message02;
    TextView message03;
    TextView message10;
    TextView message11;
    TextView message12;
    TextView message13;
    TextView message20;
    TextView message21;
    TextView message22;
    TextView message23;
    TextView message30;
    TextView message31;
    TextView message32;
    TextView message33;



    boolean playerMoved = false;
    int height = 4;
    int width = 4;
    int goalX = 3;
    int goalY = 3;
    int playerX = 0;
    int playerY = 0;
    int currentNumber = 2;
    int moveCounter = 0;
    int targetX;
    int targetY;
    String winningMessage = "You Win";
    String errorMessage = "You can't move there";
    ArrayList<String> myMovesDirection = new ArrayList<String>();
    ArrayList<Integer> myMovesDistance = new ArrayList<Integer>();
    ArrayList<String> myMoves = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        button = (Button) findViewById(R.id.button1);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openLevel1();
            }
        });

        button = (Button) findViewById(R.id.button2);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openLevel2();
            }
        });

        button = (Button) findViewById(R.id.button3);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openLevel3();
            }
        });

        button = (Button) findViewById(R.id.button4);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openLevel4();
            }
        });

        button = (Button) findViewById(R.id.button5);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openLevel5();
            }
        });

        button = (Button) findViewById(R.id.button6);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openLevel6();
            }
        });

        button = (Button) findViewById(R.id.button7);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openLevel7();
            }
        });

        button = (Button) findViewById(R.id.button8);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openLevel8();
            }
        });

        button = (Button) findViewById(R.id.button9);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openLevel9();
            }
        });

        button = (Button) findViewById(R.id.button10);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openLevel10();
            }
        });

        button = (Button) findViewById(R.id.b00);                                                   //Startmoving
        message00 = (TextView)findViewById(R.id.b00);
        button = (Button)findViewById(R.id.b00);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                targetY = 0;
                targetX = 0;
                MovePlayer();
                playerMoved=false;
                moveErrorMessage(errorMessage);
                if (playerMoved = true) {
                    message00.setText("{2}");
                }else{

                }
            }
        });

        button = (Button) findViewById(R.id.b01);                                                   //Startmoving
        message01 = (TextView)findViewById(R.id.b01);
        button = (Button)findViewById(R.id.b01);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                targetY = 0;
                targetX = 1;
                MovePlayer();
                if (playerMoved = true){
                    message01.setText("{2}");
                }
            }
        });

        button = (Button) findViewById(R.id.b02);                                                   //Startmoving
        message02 = (TextView)findViewById(R.id.b02);
        button = (Button)findViewById(R.id.b02);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                targetY = 0;
                targetX = 2;
                MovePlayer();
                if (playerMoved = true){
                    message02.setText("{2}");
                }
            }
        });

        button = (Button) findViewById(R.id.b03);
        message03 = (TextView)findViewById(R.id.b03);
        button = (Button)findViewById(R.id.b03);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                targetY = 0;
                targetX = 3;
                MovePlayer();
                if (playerMoved = true){
                    message03.setText("{2}");
                }
            }
        });

        button = (Button) findViewById(R.id.b10);
        message10 = (TextView)findViewById(R.id.b10);
        button = (Button)findViewById(R.id.b10);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                targetY = 1;
                targetX = 0;
                MovePlayer();
                if (playerMoved = true){
                    message10.setText("{2}");
                }
            }
        });

        button = (Button) findViewById(R.id.b11);
        message11 = (TextView)findViewById(R.id.b11);
        button = (Button)findViewById(R.id.b11);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                targetY = 1;
                targetX = 1;
                MovePlayer();
                if (playerMoved = true){
                    message11.setText("{3}");
                }
            }
        });

        button = (Button) findViewById(R.id.b12);
        message12 = (TextView)findViewById(R.id.b12);
        button = (Button)findViewById(R.id.b12);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                targetY = 1;
                targetX = 2;
                MovePlayer();
                if (playerMoved = true){
                    message12.setText("{2}");
                }
            }
        });

        button = (Button) findViewById(R.id.b13);
        message13 = (TextView)findViewById(R.id.b13);
        button = (Button)findViewById(R.id.b13);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                targetY = 1;
                targetX = 3;
                MovePlayer();
                if (playerMoved = true){
                    message13.setText("{3}");
                }
            }
        });

        button = (Button) findViewById(R.id.b20);
        message20 = (TextView)findViewById(R.id.b20);
        button = (Button)findViewById(R.id.b20);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                targetY = 2;
                targetX = 0;
                MovePlayer();
                if (playerMoved = true){
                    message20.setText("{2}");
                }
            }
        });

        button = (Button) findViewById(R.id.b21);
        message21 = (TextView)findViewById(R.id.b21);
        button = (Button)findViewById(R.id.b21);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                targetY = 2;
                targetX = 1;
                MovePlayer();
                if (playerMoved = true){
                    message21.setText("{1}");
                }
            }
        });

        button = (Button) findViewById(R.id.b22);
        message22 = (TextView)findViewById(R.id.b22);
        button = (Button)findViewById(R.id.b22);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                targetY = 2;
                targetX = 2;
                MovePlayer();
                if (playerMoved = true){
                    message22.setText("{1}");
                }
            }
        });

        button = (Button) findViewById(R.id.b23);
        message23 = (TextView)findViewById(R.id.b23);
        button = (Button)findViewById(R.id.b23);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                targetY = 2;
                targetX = 3;
                MovePlayer();
                if (playerMoved = true){
                    message23.setText("{2}");
                }
            }
        });

        button = (Button) findViewById(R.id.b30);
        message30 = (TextView)findViewById(R.id.b30);
        button = (Button)findViewById(R.id.b30);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                targetY = 3;
                targetX = 0;
                MovePlayer();
                if (playerMoved = true){
                    message30.setText("{3}");
                }
            }
        });

        button = (Button) findViewById(R.id.b31);
        message31 = (TextView)findViewById(R.id.b31);
        button = (Button)findViewById(R.id.b31);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                targetY = 3;
                targetX = 1;
                MovePlayer();
                if (playerMoved = true){
                    message31.setText("{2}");
                }
            }
        });

        button = (Button) findViewById(R.id.b32);
        message32 = (TextView)findViewById(R.id.b32);
        button = (Button)findViewById(R.id.b32);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                targetY = 3;
                targetX = 2;
                MovePlayer();
                if (playerMoved = true){
                    message32.setText("{2}");
                }
            }
        });

        button = (Button) findViewById(R.id.b33);
        message33 = (TextView)findViewById(R.id.b33);
        button = (Button)findViewById(R.id.b33);
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                targetY = 3;
                targetX = 3;
                MovePlayer();
                if (playerMoved = true) {
                    message33.setText("{0}");
                }
                youWinMessage(winningMessage);
                /*
                if (playerX == 3 && playerY == 3){
                    youWinMessage(winningMessage);
                }*/
            }
        });
    }
    public void openLevel1() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void openLevel2() {
        Intent intent = new Intent(this, Level2.class);
        startActivity(intent);
    }

    public void openLevel3() {
        Intent intent = new Intent(this, Level3.class);
        startActivity(intent);
    }

    public void openLevel4() {
        Intent intent = new Intent(this, Level4.class);
        startActivity(intent);
    }

    public void openLevel5() {
        Intent intent = new Intent(this, Level5.class);
        startActivity(intent);
    }

    public void openLevel6() {
        Intent intent = new Intent(this, Level6.class);
        startActivity(intent);
    }

    public void openLevel7() {
        Intent intent = new Intent(this, Level7.class);
        startActivity(intent);
    }

    public void openLevel8() {
        Intent intent = new Intent(this, Level8.class);
        startActivity(intent);
    }

    public void openLevel9() {
        Intent intent = new Intent(this, Level9.class);
        startActivity(intent);
    }

    public void openLevel10() {
        Intent intent = new Intent(this, Level10.class);
        startActivity(intent);
    }

    public void youWinMessage(String winningMessage) {
        AlertDialog dlg = new AlertDialog.Builder(MainActivity.this)
                .setTitle("Congratulations!!")
                .setMessage(winningMessage)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                //dialog.dismess();
            }
        })
                .create();
        dlg.show();

    }

    public void moveErrorMessage(String errorMessage) {
        AlertDialog dlg = new AlertDialog.Builder(MainActivity.this)
                .setTitle("Wrong move")
                .setMessage(errorMessage)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //dialog.dismess();
                    }
                })
                .create();
        dlg.show();

    }


    public void MovePlayer() {
        if (playerX == (targetX - currentNumber)) {
            MovePlayerRight();
        } else if (playerX == (targetX + currentNumber)){
            MovePlayerLeft();
        } else if (playerY == (targetY + currentNumber)){
            MovePlayerDown();
        } else if (playerY == (targetY - currentNumber)){
            MovePlayerUp();
        } else{
            playerMoved = false;
        }
    }

    public void MovePlayerUp() {							//Feature 3 move player up			Feature 12 Move counter		Feature 13 Move List
        if (playerY - currentNumber < 0){

        }
        else {
            playerY = playerY - currentNumber;
            moveCounter++;
            myMovesDirection.add("Up");
            myMovesDistance.add(currentNumber);
            playerMoved = true;

        }

    }

    public void MovePlayerDown() {							//Feature 4 move player down		Feature 12 Move counter		Feature 13 Move List
        if (playerY + currentNumber > height){

        }
        else {
            playerY = playerY + currentNumber;
            moveCounter++;
            myMovesDirection.add("Down");
            myMovesDistance.add(currentNumber);
            playerMoved = true;
        }
    }

    public void MovePlayerLeft() {							//Feature 5 move player left		Feature 12 Move counter		Feature 13 Move List
        if (playerX - currentNumber < 0){
            playerMoved = false;
            moveErrorMessage(errorMessage);
        }
        else {
            playerX = playerX - currentNumber;
            moveCounter++;
            myMovesDirection.add("Left");
            myMovesDistance.add(currentNumber);
            playerMoved = true;
        }
    }

    public void MovePlayerRight() {							//Feature 6 move player right		Feature 12 Move counter		Feature 13 Move List
        if (playerX + currentNumber > width){

        }
        else {
            playerX = playerX + currentNumber;
            moveCounter++;
            myMovesDirection.add("Right");
            myMovesDistance.add(currentNumber);
            playerMoved = true;
        }
    }
}