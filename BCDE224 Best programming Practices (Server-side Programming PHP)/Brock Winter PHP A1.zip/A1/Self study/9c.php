<?php

declare(strict_types=1);

function add(float  $firstFloat, float  $secondFloat)
{
    return $firstFloat + $secondFloat;
}

echo add(2.3, 2.7); 
?>