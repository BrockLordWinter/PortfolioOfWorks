use agoradb;
select * from buyer;
select * from addtocart;
select * from favourite;
select * from stock;
select * from product;
select * from myfavourites;
select * from cart;
select * from supplier;

/*Simple query or search query, not sure which*/ 
SELECT fName, lName, address FROM buyer WHERE buyerId > 1 ORDER BY lName, fName;

/*update*/
UPDATE cart
INNER JOIN addtocart ON cart.cartId = addtocart.cartId
SET cart.totalCost = cart.totalCost + addtocart.totalPrice
WHERE cart.buyerId = 1;


DELIMITER $$

CREATE TRIGGER update_cart_total
AFTER INSERT ON addtocart
FOR EACH ROW
BEGIN
  UPDATE cart set totalCost = (cart.totalCost + addtocart.totalPrice) where cart.cartID=addtocart.cartId;
END$$

DELIMITER ;

