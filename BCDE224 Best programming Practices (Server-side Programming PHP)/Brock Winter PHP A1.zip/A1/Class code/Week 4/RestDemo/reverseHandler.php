<?php
require './Reverse.php';

header( 'Content-Type: application/json' );


if (isset($_SERVER['QUERY_STRING'])) 
{
	$input = $_SERVER['QUERY_STRING'];
	$reversed = new Reversed($input);	
	$reversed->convert();
	$answer = $reversed->getRevStr();
	$result = [$input, $answer];
	echo json_encode($result);	
}
?>