﻿namespace Brock_A2_Sem2_2022
{
    public interface ILoader
    {
        string Load(string fileName);
    }
}
