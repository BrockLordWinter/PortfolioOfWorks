<?php 

$x = 1;
$y = 2;

$z = $x + $y;
echo $z;
