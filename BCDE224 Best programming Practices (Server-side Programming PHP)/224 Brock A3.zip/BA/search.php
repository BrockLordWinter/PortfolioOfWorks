<?php
	include_once 'siteFunctions/commonFunctions.php';
	include_once 'siteFunctions/masterPage.php';
	require_once 'framework/htmlTemplate.php';
	require_once 'framework/htmlTable.php';

	$page = new MasterPage();
	
	$content="";

	// get any specified search terms from the URL or the form
	$keywords= getFromUrl('search');

	// show the results if we have any search terms

	if (isSpecified($keywords) ){
		$db = $page->getDB();
		$sql="select productId, supplierId, productName, productDescription, price".
			 "from product where productId like '%$keywords%' or ".
			 "productId like '%$keywords%' or ".
			 "productName like '%$keywords%' ".
			 "order by productId, supplierId, productName";
		//print $sql;
		$product = $db->query($sql);
		if ($product!=false) {
			if ($product->size()==0) {
				$content="<p>No product found for $keywords</p>";
			} else {
				// Format the product as an HTML table
				$table=new HtmlTable ($product);
				
				

				$content= $table->getHtml( array (
					'productId'=>'Add Item to Crart ID',
					'cartId'=>'Cart ID',
					'productId'=>'Product ID',
					'productName'=>'Product Name'));	
			}
		}
	}
	
	/*if (isSpecified($keywords) ){
		$db = $page->getDB();
		$sql="select addToCartId, cartId, productId, productName, discountAmount, quantity, price, price".
			 "from addToCart where addToCartId like '%$keywords%' or ".
			 "addToCartId like '%$keywords%' or ".
			 "productName like '%$keywords%' ".
			 "order by addToCartId, cartId, productName";
		//print $sql;
		$product = $db->query($sql);
		if ($product!=false) {
			if ($product->size()==0) {
				$content="<p>No product found for $keywords</p>";
			} else {
				// Format the product as an HTML table
				$table=new HtmlTable ($product);
				
				

				$content= $table->getHtml( array (
					'addToCartId'=>'Add Item to Crart ID',
					'cartId'=>'Cart ID',
					'productId'=>'Product ID',
					'productName'=>'Product Name'));	
			}
		}
	}*/
	
	// Note - we always show a search form so the user can do another search
	$form = new HtmlTemplate('search.html');

	// show any old values we have in the form
	$oldValues=array('oldSearch'=>getOldValue($keywords));
		
	// add the form to the results
	$content .= $form->getHtml($oldValues);
	
	// Finally, place the content in our master page
	$page->setTitle('product search');
	$page->setContent($content);	
	print $page->getHtml();
		
	// returns true if a search term is not blank
	function isSpecified ($var) {
		if ($var==null || trim($var =='')) {
			return false;
		}
		return true;
	}
	
	// If we have a value return ~ value='xxx' else return blank
	function getOldValue ($val) {
		if ($val==null) {
			return "";
		}
		return ' value="'.$val.'" ';
	}
