<?php
class Toy 
{
	public $name;
	public $color;
	public $cost;
	
  function __construct($newName, $newColor, $newCost) 
  {
    $this->name = $newName;
    $this->color = $newColor;
    $this->cost = $newCost;
  }
  function __toString() 
  {
    //  $result = $this->name .  '(' .$this->color . ' ) @ $' . $this->cost;
	$result = "$this->name ($this->color) @ $$this->cost";
    return $result;
  }
}
class Box { 
	protected $toyCount = 0;
	protected $allMyToys = array();

  function addToy($newName, $newColor, $newCost) 
  {
    $aNewToy = new Toy($newName, $newColor, $newCost);
    $this->allMyToys[] =  $aNewToy;
    $this->toyCount += 1;
  }
  function sortToys () 
  {
	  usort($this->allMyToys,  function ($a, $b) {return strcmp($a->name, $b->name); });
  }
  function __toString () 
  {
    $this->sortToys();
    $result = "<br>This toybox has $this->toyCount toys<br>";
	$result .=  '<ul>';
    foreach ($this->allMyToys as $aToy) 
	{
      $result .= "<li>$aToy</li>";
    }
	$result .= '</ul>';
    return $result;
  }
}

$theBox = new Box();
$theBox->addToy('Bear', 'brown', 12.34);
$theBox->addToy('Aadrvard', 'black', .12);
$theBox->addToy('Doll', 'pink', 34.36);
var_dump($theBox);

echo $theBox;
