<?php
	$name = 'Brock';
	$myNumber = 8;
	$myFloat = 8.06527;
	$myBoolean = true;
	echo $name,' ',$myNumber,' ',$myFloat,' ',$myBoolean;
?>
